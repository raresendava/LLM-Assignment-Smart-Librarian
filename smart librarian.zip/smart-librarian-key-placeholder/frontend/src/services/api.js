const API = import.meta.env.VITE_API_BASE || 'http://localhost:8000';

export async function rebuildIndex() {
  const r = await fetch(`${API}/api/index`, { method: 'POST' })
  return r.json()
}

export async function recommend(query) {
  const r = await fetch(`${API}/api/recommend`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ query })
  })
  if (!r.ok) throw new Error((await r.json()).error || 'Request failed')
  return r.json()
}

export async function transcribe(blob) {
  const form = new FormData()
  form.append('file', blob, 'audio.webm')
  const r = await fetch(`${API}/api/transcribe`, { method: 'POST', body: form })
  if (!r.ok) throw new Error((await r.json()).error || 'Transcription failed')
  return r.json()
}
