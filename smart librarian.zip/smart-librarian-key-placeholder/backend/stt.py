import os, io
from openai import OpenAI

def transcribe_audio_bytes(data: bytes, filename: str = "audio.webm") -> str:
    client = OpenAI()
    # Send bytes via in-memory file
    with io.BytesIO(data) as f:
        f.name = filename
        transcript = client.audio.transcriptions.create(model="whisper-1", file=f)
    return transcript.text
