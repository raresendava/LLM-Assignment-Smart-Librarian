import json, os
from typing import Optional

DATA_PATH = os.path.join("data", "full_summaries.json")

def load_full_summaries() -> dict:
    if not os.path.exists(DATA_PATH):
        return {}
    with open(DATA_PATH, "r", encoding="utf-8") as f:
        return json.load(f)

FULL = load_full_summaries()

def get_summary_by_title(title: str) -> Optional[str]:
    return FULL.get(title)
