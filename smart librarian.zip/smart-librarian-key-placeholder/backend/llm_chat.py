from typing import Dict, Any
from openai import OpenAI

SYSTEM = """You are a helpful librarian. 
Given user interests and a small set of candidate books (title, themes, short summary), pick ONE best title. 
Then call the provided tool get_summary_by_title with the exact title to fetch a longer summary.
Be concise but warm; reference why the pick matches the user's interests.
If candidates are weak, ask one clarifying question instead of guessing blindly.
"""

def choose_and_enrich(query: str, candidates: list) -> Dict[str, Any]:
    client = OpenAI()
    # Prepare messages
    messages = [
        {"role": "system", "content": SYSTEM},
        {"role": "user", "content": f"My interests: {query}"},
        {"role": "user", "content": "Candidates:\n" + "\n".join([f"- {c['title']} | themes: {c['themes']}\n  {c['summary']}" for c in candidates])},
    ]
    # Define tool schema
    tools = [{
        "type": "function",
        "function": {
            "name": "get_summary_by_title",
            "description": "Return the longer summary for the given exact book title.",
            "parameters": {
                "type": "object",
                "properties": {
                    "title": {"type": "string", "description": "Exact book title from the candidates list"}
                },
                "required": ["title"]
            }
        }
    }]
    # First call
    r1 = client.chat.completions.create(model="gpt-4o-mini", messages=messages, tools=tools, tool_choice="auto")
    msg = r1.choices[0].message
    # Tool call?
    if msg.tool_calls:
        tc = msg.tool_calls[0]
        if tc.function.name == "get_summary_by_title":
            import json
            args = json.loads(tc.function.arguments or "{}")
            title = args.get("title", "")
            # Return tool call request for the caller to execute.
            return {"tool_request": {"name": "get_summary_by_title", "title": title}, "assistant_thought": msg.content or ""}
    # If no tool call, return assistant content
    return {"final_text": msg.content or "I couldn't determine a good recommendation."}
