import os, base64, time
from typing import Optional
from openai import OpenAI
from PIL import Image
from io import BytesIO

GEN_DIR = os.path.join("generated", "images")
os.makedirs(GEN_DIR, exist_ok=True)

def cover_prompt(title: str, themes: str) -> str:
    return f"Create a clean, book-cover-like illustration for the novel '{title}'. Emphasize the themes: {themes}. Minimalist, high-contrast, readable title typography, centered composition, soft lighting."

def generate_cover_image(title: str, themes: str, model: Optional[str] = None) -> str:
    client = OpenAI()
    model = model or os.getenv("OPENAI_IMAGE_MODEL", "gpt-image-1")
    prompt = cover_prompt(title, themes)
    res = client.images.generate(model=model, prompt=prompt, size="1024x1024")
    b64 = res.data[0].b64_json
    img = Image.open(BytesIO(base64.b64decode(b64)))
    ts = int(time.time()*1000)
    out_path = os.path.join(GEN_DIR, f"{title.replace(' ','_')}_{ts}.png")
    img.save(out_path)
    return out_path
