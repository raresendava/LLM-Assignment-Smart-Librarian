# Smart Librarian — Backend (FastAPI + RAG)

This backend implements:
- RAG over short book summaries using **ChromaDB** + **OpenAI embeddings**.
- A **tool** `get_summary_by_title` returning longer summaries.
- Profanity check (local wordlist + optional OpenAI moderation).
- **TTS** (gTTS) to produce an MP3 of the final answer.
- **STT** using OpenAI Whisper API (upload audio from frontend).
- **Image generation** (OpenAI `gpt-image-1`) for a cover-like image.
- REST endpoints for a React frontend and a minimal CLI / Streamlit.

## Prereqs
- Python 3.10+ recommended.
- An OpenAI API key in `.env` (copy `.env.example` → `.env`).

## Install
```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## Build (or rebuild) the vector index
```bash
python rag_index.py
```

## Run API
```bash
uvicorn main:app --reload --port 8000
```

## Optional: CLI
```bash
python app_cli.py
```

## Optional: Streamlit
```bash
streamlit run app_streamlit.py
```

## Endpoints (summary)
- `POST /api/index` — rebuild the RAG index from `data/book_summaries.md`.
- `GET /api/books` — list known titles.
- `POST /api/recommend` — body: `{ "query": "..." }` → returns best title, long summary, candidates, mp3 path, and image path.
- `POST /api/transcribe` — multipart audio upload → STT text via Whisper.
- `GET /api/cover?title=The Hobbit` — (re)generate a cover-like image for a title.
- `GET /api/tts?text=...` — TTS for arbitrary text (returns mp3 path).

Static/media files are served from `/static/...`.
