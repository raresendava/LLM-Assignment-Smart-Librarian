import streamlit as st
import requests

st.set_page_config(page_title="Smart Librarian", page_icon="📚")
st.title("📚 Smart Librarian")

api = st.text_input("API base URL", value="http://localhost:8000")
query = st.text_input("Tell me what you're in the mood for…", placeholder="friendship and magic, a fast-paced sci-fi, a classic about freedom...")

col1, col2 = st.columns(2)
with col1:
    if st.button("Rebuild Index"):
        r = requests.post(f"{api}/api/index")
        st.success(r.json())

with col2:
    go = st.button("Recommend")

if go and query.strip():
    r = requests.post(f"{api}/api/recommend", json={"query": query})
    if r.status_code != 200:
        st.error(r.json())
    else:
        data = r.json()
        st.markdown(data.get("final_text",""))
        if data.get("cover_image"):
            st.image(f"{api}{data['cover_image']}", caption=data.get("title") or "")
        if data.get("tts_mp3"):
            st.audio(f"{api}{data['tts_mp3']}")
        st.write("Candidates:", data.get("candidates", []))
