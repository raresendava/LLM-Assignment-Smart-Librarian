import os, time
from gtts import gTTS

GEN_DIR = os.path.join("generated", "audio")

def ensure_dir():
    os.makedirs(GEN_DIR, exist_ok=True)

def synthesize_to_mp3(text: str, basename: str = "speech") -> str:
    ensure_dir()
    ts = int(time.time() * 1000)
    filename = f"{basename}_{ts}.mp3"
    path = os.path.join(GEN_DIR, filename)
    tts = gTTS(text=text)
    tts.save(path)
    return path
