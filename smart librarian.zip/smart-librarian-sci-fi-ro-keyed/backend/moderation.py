from typing import Tuple
import re, os
from openai import OpenAI

# A tiny local wordlist as a first pass. Expand as needed.
_BAD_WORDS = {"damn", "shit", "asshole", "bastard", "bitch", "fuck"}

def local_profanity_check(text: str) -> Tuple[bool, str]:
    lowered = text.lower()
    for w in _BAD_WORDS:
        if re.search(rf"\b{re.escape(w)}\b", lowered):
            return True, f"Found prohibited word: {w}"
    return False, ""

def openai_moderation_check(text: str) -> Tuple[bool, str]:
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        return False, "No OpenAI key; skipped remote moderation."
    client = OpenAI()
    try:
        resp = client.moderations.create(model="omni-moderation-latest", input=text)
        flagged = bool(resp.results[0].flagged)
        return flagged, "OpenAI moderation flagged content." if flagged else ""
    except Exception as e:
        return False, f"Moderation error: {e}"
