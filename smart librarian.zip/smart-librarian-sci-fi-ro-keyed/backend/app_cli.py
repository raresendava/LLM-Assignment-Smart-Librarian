import json
from retriever import semantic_search
from tools import get_summary_by_title
from llm_chat import choose_and_enrich
from moderation import local_profanity_check

def main():
    print("Smart Librarian (CLI). Type something like: a book about friendship and magic")
    while True:
        q = input("\nYour interests (or 'quit'): ").strip()
        if q.lower() in {"quit", "exit"}:
            break
        flagged, reason = local_profanity_check(q)
        if flagged:
            print("Sorry, that input contains profanity:", reason)
            continue
        retrieved = semantic_search(q, k=3)
        choice = choose_and_enrich(q, retrieved["candidates"])
        if "tool_request" in choice:
            title = choice["tool_request"]["title"]
            long_summary = get_summary_by_title(title) or "(No long summary found.)"
            print(f"\nRecommendation: {title}\n\n{long_summary}\n")
        else:
            print("\n", choice.get("final_text", "No recommendation."), "\n")

if __name__ == "__main__":
    main()
