import os, re, json
from dotenv import load_dotenv
import chromadb
from chromadb.config import Settings
from openai import OpenAI

load_dotenv()
EMBED_MODEL = os.getenv("OPENAI_EMBED_MODEL", "text-embedding-3-small")
PERSIST_DIR = os.getenv("CHROMA_PERSIST_DIR", "./chroma")
DATA_PATH = os.path.join("data", "book_summaries.md")

client = OpenAI()

def parse_markdown(md_text: str):
    # Split on headings '## Title:'
    entries = []
    blocks = re.split(r"\n##\s*Title:\s*", "\n"+md_text.strip())
    for block in blocks:
        block = block.strip()
        if not block: 
            continue
        # First line until newline is title
        lines = block.splitlines()
        title = lines[0].strip()
        themes_line = ""
        summary_lines = []
        for ln in lines[1:]:
            if ln.lower().startswith("themes:"):
                themes_line = ln.split(":",1)[1].strip()
            elif ln.lower().startswith("summary:"):
                summary_lines.append(ln.split(":",1)[1].strip())
            else:
                summary_lines.append(ln.strip())
        summary = " ".join(summary_lines).strip()
        entries.append({"title": title, "themes": themes_line, "summary": summary})
    return entries

def build_index():
    if not os.path.exists(DATA_PATH):
        raise FileNotFoundError(f"Missing {DATA_PATH}")
    with open(DATA_PATH, "r", encoding="utf-8") as f:
        md = f.read()
    records = parse_markdown(md)

    os.makedirs(PERSIST_DIR, exist_ok=True)
    db = chromadb.PersistentClient(path=PERSIST_DIR, settings=Settings(anonymized_telemetry=False))
    col = db.get_or_create_collection(name="books", metadata={"hnsw:space": "cosine"})

    # Clear existing
    try:
        existing = col.get()
        if existing and existing.get("ids"):
            col.delete(ids=existing["ids"])
    except Exception:
        pass

    texts = [r["summary"] for r in records]
    titles = [r["title"] for r in records]
    embeddings = client.embeddings.create(model=EMBED_MODEL, input=texts).data
    vectors = [e.embedding for e in embeddings]

    col.add(
        ids=titles,
        embeddings=vectors,
        documents=texts,
        metadatas=[{"title": r["title"], "themes": r["themes"]} for r in records],
    )
    print(f"Indexed {len(records)} books into Chroma at {PERSIST_DIR}")

if __name__ == "__main__":
    build_index()
