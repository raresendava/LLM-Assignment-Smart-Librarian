## Title: Dune
Themes: politics, ecology, prophecy, power
Summary: On the desert planet Arrakis, noble houses scheme over the spice that fuels interstellar travel. A young heir embraces destiny amid sandworms, prophecy, and a fight for survival.

## Title: Foundation
Themes: empire, math, prediction, collapse
Summary: A psychohistorian foresees the fall of a galactic empire and seeds a plan to shorten the coming dark age. Science, strategy, and human folly collide across centuries.

## Title: Neuromancer
Themes: cyberspace, AI, crime, identity
Summary: A washed-up hacker is hired for an impossible heist through corporate ice and digital ghosts. Neon noir meets questions about selfhood in a world wired for control.

## Title: The Left Hand of Darkness
Themes: gender, diplomacy, trust, survival
Summary: On a frozen world where gender is fluid, an envoy and a suspected traitor cross glaciers and politics. Their bond reframes what it means to understand another culture.

## Title: The Three-Body Problem
Themes: first contact, physics, betrayal, survival
Summary: Signals from Earth draw the attention of a desperate alien civilization. Secret societies, VR puzzles, and cosmic timelines test humanity’s will to persist.

## Title: Hyperion
Themes: pilgrimage, myth, time, fate
Summary: Seven travelers tell interlocking tales en route to a deadly shrine and a creature called the Shrike. War looms as personal histories spiral toward a singular mystery.

## Title: Snow Crash
Themes: metaverse, language, corporate power, satire
Summary: A samurai-sword-carrying hacker-courier races to stop a mind-hacking memetic virus. Pizza mafias, virtual realities, and ancient linguistics crash together at high speed.

## Title: The Martian
Themes: survival, engineering, humor, resilience
Summary: Stranded on Mars, an astronaut farms, hacks, and problem-solves his way through one crisis after another. A love letter to ingenuity and duct-tape thinking.

## Title: Annihilation
Themes: ecology, mystery, transformation, secrecy
Summary: An expedition enters a quarantined zone where nature is uncanny and memory slippery. Journals, spores, and shifting selves blur the line between observer and observed.

## Title: Solaris
Themes: consciousness, grief, alien intelligence, memory
Summary: Scientists orbit an ocean planet that manifests human memories. An intimate encounter with the unknowable asks whether we can ever meet the truly alien.

## Title: Childhood's End
Themes: utopia, evolution, loss, transcendence
Summary: Benevolent overlords end war and hunger—but at a cost that transforms humanity into something beyond itself. A quiet apocalypse of wonder and melancholy.

## Title: Fundația
Themes: imperiu, matematică, predicție, declin
Summary: Un savant prevede căderea imperiului galactic și pornește un plan pentru a scurta epoca întunecată. Știință, strategie și slăbiciuni omenești peste secole.

## Title: Problema celor trei corpuri
Themes: prim contact, fizică, trădare, supraviețuire
Summary: Semnalele de pe Pământ atrag atenția unei civilizații extraterestre disperate. Societăți secrete, jocuri VR și scări cosmice pun la încercare voința umanității de a dăinui.
