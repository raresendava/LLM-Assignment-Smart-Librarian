import os, io, json
from typing import List, Dict, Any, Optional
from fastapi import FastAPI, UploadFile, File, Form, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from dotenv import load_dotenv

from retriever import semantic_search
from tools import get_summary_by_title
from llm_chat import choose_and_enrich
from moderation import local_profanity_check, openai_moderation_check
from tts import synthesize_to_mp3
from image_gen import generate_cover_image
import rag_index

load_dotenv()

app = FastAPI(title="Smart Librarian API")

# CORS
origins = os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Static files (serve generated assets)
os.makedirs("generated", exist_ok=True)
app.mount("/static", StaticFiles(directory="generated"), name="static")

@app.post("/api/index")
def rebuild_index():
    rag_index.build_index()
    return {"status": "ok"}

@app.get("/api/books")
def list_books():
    # Read from Chroma metadata by querying with a dummy vector is heavy.
    # Instead, parse data file to list titles.
    path = os.path.join("data", "book_summaries.md")
    if not os.path.exists(path):
        return {"books": []}
    import re
    with open(path, "r", encoding="utf-8") as f:
        md = f.read()
    titles = re.findall(r"^##\s*Title:\s*(.+)$", md, flags=re.MULTILINE)
    return {"books": titles}

@app.post("/api/recommend")
async def recommend(payload: Dict[str, Any]):
    query: str = (payload or {}).get("query", "").strip()
    if not query:
        return JSONResponse({"error": "Missing 'query'."}, status_code=400)

    # Profanity checks
    flagged, reason = local_profanity_check(query)
    if flagged:
        return JSONResponse({"error": f"Query rejected due to profanity: {reason}"}, status_code=400)
    flagged_remote, reason_remote = openai_moderation_check(query)
    if flagged_remote:
        return JSONResponse({"error": f"Query rejected by moderation: {reason_remote}"}, status_code=400)

    # Retrieve candidates
    retrieved = semantic_search(query, k=3)
    candidates = retrieved["candidates"]

    # Let the LLM choose and request tool call
    choice = choose_and_enrich(query, candidates)

    long_summary = None
    title = None
    assistant_thought = ""
    if "tool_request" in choice:
        tr = choice["tool_request"]
        title = tr.get("title")
        assistant_thought = choice.get("assistant_thought", "")
        long_summary = get_summary_by_title(title) if title else None
        if not long_summary:
            return {"message": "I picked a book but couldn't find its full summary.", "title": title, "candidates": candidates}
        final_text = f"I recommend **{title}**.\n\n{long_summary}"
    else:
        final_text = choice.get("final_text", "I couldn't determine a good recommendation.")

    # TTS
    mp3_path = synthesize_to_mp3(final_text, basename="recommendation")
    mp3_url = f"/static/audio/{os.path.basename(mp3_path)}"

    # Image (cover-like) — use themes from top candidate matching the chosen title
    chosen = None
    for c in candidates:
        if c["title"] == title:
            chosen = c
            break
    img_path = None
    if chosen:
        try:
            img_path = generate_cover_image(title=chosen["title"], themes=chosen.get("themes",""))
        except Exception as e:
            img_path = None
    img_url = f"/static/images/{os.path.basename(img_path)}" if img_path else None

    return {
        "title": title,
        "final_text": final_text,
        "assistant_note": assistant_thought,
        "candidates": candidates,
        "tts_mp3": mp3_url,
        "cover_image": img_url
    }

@app.post("/api/transcribe")
async def transcribe(file: UploadFile = File(...)):
    data = await file.read()
    # Use OpenAI Whisper API
    from stt import transcribe_audio_bytes
    try:
        text = transcribe_audio_bytes(data, filename=file.filename or "audio.webm")
    except Exception as e:
        return JSONResponse({"error": f"Transcription failed: {e}"}, status_code=500)
    return {"text": text}

@app.get("/api/cover")
def cover(title: str = Query(...), themes: Optional[str] = Query("", description="Optional themes override")):
    # Reuse metadata if themes not provided
    if not themes:
        # quick retrieve theme from dataset
        import re
        with open(os.path.join("data", "book_summaries.md"), "r", encoding="utf-8") as f:
            md = f.read()
        pat = rf"##\s*Title:\s*{re.escape(title)}\s*[\r\n]+Themes:\s*(.+)"
        m = re.search(pat, md, flags=re.IGNORECASE)
        themes = m.group(1) if m else ""
    try:
        path = generate_cover_image(title, themes)
        url = f"/static/images/{os.path.basename(path)}"
        return {"image": url}
    except Exception as e:
        return JSONResponse({"error": f"Image generation failed: {e}"}, status_code=500)

@app.get("/api/tts")
def tts(text: str = Query(...)):
    try:
        path = synthesize_to_mp3(text, basename="say")
        url = f"/static/audio/{os.path.basename(path)}"
        return {"audio": url}
    except Exception as e:
        return JSONResponse({"error": f"TTS failed: {e}"}, status_code=500)
