import os
from typing import List, Dict, Any
import chromadb
from chromadb.config import Settings
from dotenv import load_dotenv
from openai import OpenAI

load_dotenv()
EMBED_MODEL = os.getenv("OPENAI_EMBED_MODEL", "text-embedding-3-small")
PERSIST_DIR = os.getenv("CHROMA_PERSIST_DIR", "./chroma")

client = OpenAI()

def get_collection():
    db = chromadb.PersistentClient(path=PERSIST_DIR, settings=Settings(anonymized_telemetry=False))
    return db.get_or_create_collection(name="books", metadata={"hnsw:space": "cosine"})

def semantic_search(query: str, k: int = 3) -> Dict[str, Any]:
    col = get_collection()
    emb = client.embeddings.create(model=EMBED_MODEL, input=[query]).data[0].embedding
    res = col.query(query_embeddings=[emb], n_results=k, include=["documents", "metadatas", "distances"])
    # Shape results
    items = []
    for i in range(len(res["ids"][0])):
        items.append({
            "title": res["ids"][0][i],
            "summary": res["documents"][0][i],
            "themes": res["metadatas"][0][i].get("themes", ""),
            "score": 1 - res["distances"][0][i] if res.get("distances") else None
        })
    return {"query": query, "candidates": items}
