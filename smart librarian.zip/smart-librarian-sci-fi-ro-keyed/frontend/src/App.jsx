import React, { useEffect, useRef, useState } from 'react'
import './app.css'
import { rebuildIndex, recommend, transcribe } from './services/api'

export default function App() {
  const [apiBase, setApiBase] = useState('http://localhost:8000')
  const [query, setQuery] = useState('friendship and magic')
  const [loading, setLoading] = useState(false)
  const [result, setResult] = useState(null)
  const [error, setError] = useState('')
  const [recording, setRecording] = useState(false)
  const mediaRecorderRef = useRef(null)
  const chunksRef = useRef([])

  useEffect(() => {
    // allow override via input box
    const v = localStorage.getItem('apiBase')
    if (v) setApiBase(v)
  }, [])

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true })
      const mr = new MediaRecorder(stream)
      mediaRecorderRef.current = mr
      chunksRef.current = []
      mr.ondataavailable = e => chunksRef.current.push(e.data)
      mr.onstop = async () => {
        const blob = new Blob(chunksRef.current, { type: 'audio/webm' })
        try {
          const { text } = await transcribe(blob)
          setQuery(text)
        } catch (e) {
          setError(String(e))
        }
      }
      mr.start()
      setRecording(true)
    } catch (e) {
      setError(String(e))
    }
  }

  const stopRecording = () => {
    if (mediaRecorderRef.current && recording) {
      mediaRecorderRef.current.stop()
      setRecording(false)
    }
  }

  const onRebuild = async () => {
    setError('')
    try {
      await rebuildIndex()
      alert('Index rebuilt.')
    } catch (e) {
      setError(String(e))
    }
  }

  const onRecommend = async () => {
    setLoading(true); setError('')
    try {
      const res = await recommend(query)
      setResult(res)
    } catch (e) {
      setError(String(e))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container">
      <h1>📚 Smart Librarian</h1>
      <div className="card" style={{marginBottom:16}}>
        <label>API Base</label>
        <input value={apiBase} onChange={e => { setApiBase(e.target.value); localStorage.setItem('apiBase', e.target.value) }} />
        <p style={{fontSize:12, color:'#6b7280'}}>Default: http://localhost:8000</p>
      </div>

      <div className="card" style={{marginBottom:16}}>
        <label>Your interests</label>
        <input value={query} onChange={e => setQuery(e.target.value)} placeholder="e.g., a book about freedom and control" />
        <div style={{display:'flex', gap:8, marginTop:12}}>
          <button onClick={onRebuild} className="secondary">Rebuild Index</button>
          <button onClick={onRecommend} disabled={loading}>{loading ? 'Thinking…' : 'Recommend'}</button>
          {!recording ? (
            <button onClick={startRecording}>🎙️ Voice</button>
          ) : (
            <button onClick={stopRecording}>⏹️ Stop</button>
          )}
        </div>
        {error && <p style={{color:'#b91c1c'}}>{error}</p>}
      </div>

      {result && (
        <div className="card">
          {result.title && <div style={{marginBottom:8}}><span className="badge">{result.title}</span></div>}
          <div dangerouslySetInnerHTML={{__html: result.final_text?.replace(/\n/g,'<br/>')}} />
          {result.cover_image && (
            <div style={{marginTop:12}}>
              <img className="cover" src={apiBase + result.cover_image} alt="Cover" />
            </div>
          )}
          {result.tts_mp3 && (
            <audio controls src={apiBase + result.tts_mp3}></audio>
          )}
          <div style={{marginTop:12}}>
            <label>Candidates</label>
            <pre className="pre">{JSON.stringify(result.candidates, null, 2)}</pre>
          </div>
        </div>
      )}
    </div>
  )
}
