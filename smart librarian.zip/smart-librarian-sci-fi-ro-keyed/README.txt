## Quick Start

### 1) Backend
```bash
cd backend
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# edit .env to add OPENAI_API_KEY=...
python rag_index.py                 # build the vector index
uvicorn main:app --reload --port 8000
```

### 2) Frontend
```bash
cd ../frontend
npm install
npm run dev
# open http://localhost:5173
```

> The frontend expects the backend at `http://localhost:8000`. You can change the base URL at the top of the page.

## Notes & Tips
- If image or STT endpoints fail, check your OpenAI key and model access.
- TTS uses **gTTS** (no API key required) and saves MP3s to `backend/generated/audio` served at `/static/audio/...`.
- Cover images are saved to `backend/generated/images` served at `/static/images/...`.
- The dataset is tailored to **science fiction** (including two Romanian-language entries) in `backend/data/`. Add or edit books there and re-run `rag_index.py`.
- The Streamlit app in `backend/app_streamlit.py` is optional if you prefer a quick local UI.
